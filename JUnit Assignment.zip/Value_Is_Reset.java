 package packagecalculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class Value_Is_Reset {

    // Test resetStoredValue method
    @Test
    public void testResetStoredValue() {
        Calculator calculator = new Calculator();
        calculator.valueStored = 100; // Set a value before resetting
        calculator.resetStoredValue(); // Reset the stored value
        assertEquals(0, calculator.valueStored, "Stored value should be reset to 0");
    }

    @Test
    public void testResetStoredValueMock() {
        // Create a mock of the Calculator
        Calculator calculator = Mockito.spy(new Calculator()); // Use spy to allow partial mocking

        // Set the initial value of valueStored
        calculator.valueStored = 100;

        // Mock the resetStoredValue() method to do nothing
        Mockito.doNothing().when(calculator).resetStoredValue();

        // Call the mocked resetStoredValue() method
        calculator.resetStoredValue();

        // Verify that resetStoredValue() was called exactly once
        Mockito.verify(calculator, Mockito.times(1)).resetStoredValue();

        // Since resetStoredValue() was mocked to do nothing, valueStored should still be 100
        assertEquals(100, calculator.valueStored, "Stored value should not be reset because the method was mocked");
    }

    // Additional test cases

    // Test after multiple resets
    @Test
    public void testMultipleResets() {
        Calculator calculator = new Calculator();
        calculator.valueStored = 200; // Set a non-zero value
        calculator.resetStoredValue(); // First reset
        calculator.resetStoredValue(); // Second reset

        assertEquals(0, calculator.valueStored, "Stored value should remain 0 after multiple resets");
    }
    // Test reset from negative value
    @Test
    public void testResetFromNegativeValue() {
        Calculator calculator = new Calculator();
        calculator.valueStored = -50; // Set a negative value
        calculator.resetStoredValue(); // Reset the stored value

        assertEquals(0, calculator.valueStored, "Stored value should be reset to 0 from a negative value");
    }

    // Test reset from large value
    @Test
    public void testResetFromLargeValue() {
        Calculator calculator = new Calculator();
        calculator.valueStored = Integer.MAX_VALUE; // Set the maximum integer value
        calculator.resetStoredValue(); // Reset the stored value

        assertEquals(0, calculator.valueStored, "Stored value should be reset to 0 from the maximum integer value");
    }

    // Test reset from minimum integer value
    @Test
    public void testResetFromMinValue() {
        Calculator calculator = new Calculator();
        calculator.valueStored = Integer.MIN_VALUE; // Set the minimum integer value
        calculator.resetStoredValue(); // Reset the stored value

        assertEquals(0, calculator.valueStored, "Stored value should be reset to 0 from the minimum integer value");
    }

    // Test reset when valueStored is already zero
    @Test
    public void testResetWhenAlreadyZero() {
        Calculator calculator = new Calculator();
        calculator.valueStored = 0; // Value is already zero
        calculator.resetStoredValue(); // Reset the stored value

        assertEquals(0, calculator.valueStored, "Stored value should remain 0 when it's already zero");
    }

}
