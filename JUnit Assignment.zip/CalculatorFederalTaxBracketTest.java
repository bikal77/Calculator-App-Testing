 package packagecalculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class CalculatorFederalTaxBracketTest{
	Calculator calculator = new Calculator();
    // Test federalTaxBracket method
    
    @Test
    void testFederalTaxBracketZero() {
        assertEquals("first", calculator.federalTaxBracket(0), "Income 0 should return 'first'");
 
    }
    @Test
    void testFederalTaxBracketFirstRange() {
   
        assertEquals("first", calculator.federalTaxBracket(53359), "Income 53359 should return 'first'");
    }
    @Test
    void testFederalTaxBracketsecondLowerrange() {
        assertEquals("second", calculator.federalTaxBracket(53360), "Income 53360 should return 'second'");
    }
    @Test
    void testFederalTaxBracketSecondEquals() {
        assertEquals("second", calculator.federalTaxBracket(80000), "Income 60000 should return 'second'");
    }
    @Test
    void testFederalTaxBracketSecondHigher() {
        assertEquals("second", calculator.federalTaxBracket(106717), "Income 106717 should return 'second'");
    }
    @Test
    void testFederalTaxBracketThirdLowerrange() {
        assertEquals("third", calculator.federalTaxBracket(106718), "Income 106718 should return 'third'");
    }
    @Test
    void testFederalTaxBracketThirdEqualrange() {
        assertEquals("third", calculator.federalTaxBracket(165430), "Income 165430 should return 'third'");
    }
    @Test
    void testFederalTaxBracketFourthLowerrange() {
        assertEquals("forth", calculator.federalTaxBracket(165431), "Income 165431 should return 'forth'");
    }
    @Test
    void testFederalTaxBracketFourthHigherrange() {
        assertEquals("forth", calculator.federalTaxBracket(235675), "Income 235675 should return 'forth'");
    }
    @Test
    void testFederalTaxBracketFifthLowerrange() {
        assertEquals("fifth", calculator.federalTaxBracket(235676), "Income 235676 should return 'fifth'");
    }
    @Test
    void testFederalTaxBracketFifthHigherrange() {
        assertEquals("fifth", calculator.federalTaxBracket(240000), "Income 240000 should return 'fifth'");
    }

    @Test
    public void testFederalTaxBracketMock() {
        Calculator calculator = Mockito.mock(Calculator.class);
        Mockito.when(calculator.federalTaxBracket(45000)).thenReturn("invalid");

        String bracket = calculator.federalTaxBracket(45000);
        assertEquals("invalid", bracket, "Income 45000 should return 'first' tax bracket");

        // Verify that the mocked method was called
        Mockito.verify(calculator).federalTaxBracket(45000);
    }
}
