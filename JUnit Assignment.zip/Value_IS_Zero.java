 package packagecalculator;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

public class Value_IS_Zero {

    // Test isValueStoredZero method

    @Test
    public void testIsValueStoredZero() {
        Calculator calculator = new Calculator();
        calculator.resetStoredValue(); // Reset to ensure value is zero
        assertTrue(calculator.isValueStoredZero(), "Stored value should be zero");

        calculator.valueStored = 10; // Changed value to 10
        assertFalse(calculator.isValueStoredZero(), "Stored value should not be zero");
    }

    @Test
    public void testIsValueStoredZeroWithMock() {
        Calculator calculator = mock(Calculator.class);
        when(calculator.isValueStoredZero()).thenReturn(true);

        assertTrue(calculator.isValueStoredZero(), "Stored value should be zero");

        // You can verify that the method was called
        verify(calculator).isValueStoredZero();
    }

    // Additional test cases
    @Test
    public void testIsValueStoredNegative() {
        Calculator calculator = new Calculator();
        calculator.valueStored = -10; // Test with a negative int value
        assertFalse(calculator.isValueStoredZero(), "Stored value should not be zero for negative values");
    }

    @Test
    public void testIsValueStoredLargePositive() {
        Calculator calculator = new Calculator();
        calculator.valueStored = 1000000; // Test with a large positive int value
        assertFalse(calculator.isValueStoredZero(), "Stored value should not be zero for large positive values");
    }

    @Test
    public void testIsValueStoredBoundaryNegativeOne() {
        Calculator calculator = new Calculator();
        calculator.valueStored = -1; // Test with the boundary value -1
        assertFalse(calculator.isValueStoredZero(), "Stored value should not be zero for -1");
    }

    @Test
    public void testIsValueStoredBoundaryPositiveOne() {
        Calculator calculator = new Calculator();
        calculator.valueStored = 1; // Test with the boundary value 1
        assertFalse(calculator.isValueStoredZero(), "Stored value should not be zero for 1");
    }

    @Test
    public void testIsValueStoredAfterReset() {
        Calculator calculator = new Calculator();
        calculator.valueStored = 500; // Set value to a non-zero number
        calculator.resetStoredValue(); // Reset the value
        assertTrue(calculator.isValueStoredZero(), "Stored value should be zero after reset");
    }
}
