 package packagecalculator;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

class CalculatorModulusTest {

    @Mock
    private Calculator calculator;

    @BeforeEach
    public void setUp() {
        calculator = new Calculator();
        // Mock the Calculator class
        calculator = Mockito.mock(Calculator.class);

        // Reset valueStored before each calculation
        doNothing().when(calculator).resetStoredValue();
    }

    @AfterEach
    public void tearDown() {
        calculator = null;
    }

    // Test modulus method
    @Test
    void testModulusNormal() {
        Calculator calculator = new Calculator();
        // Normal case: 15 % 4 = 3
        assertEquals(3, calculator.modulus(15, 4), "15 % 4 should equal 3");
    }

    @Test
    void testModulusEdge() {
        Calculator calculator = new Calculator();
        // Edge case: 12 % 6 = 0 (no remainder)
        assertEquals(0, calculator.modulus(12, 6), "12 % 6 should equal 0");
    }

    @Test
    void testModulusNegative() {
        Calculator calculator = new Calculator();
        // Negative numbers: -12 % 5 = -2
        assertEquals(-2, calculator.modulus(-12, 5), "-12 % 5 should equal -2");
    }

    @Test
    void testModulusGreater() {
        Calculator calculator = new Calculator();
        // Case where divisor is larger than dividend: 8 % 15 = 8
        assertEquals(8, calculator.modulus(8, 15), "8 % 15 should equal 8");
    }

    @Test
    void testModulusZeroNumerator() {
        Calculator calculator = new Calculator();
        assertEquals(0, calculator.modulus(0, 4), "0 % 4 should equal 0");  // Zero numerator
    }

    @Test
    void testModulusNegativeDenominator() {
        Calculator calculator = new Calculator();
        assertEquals(2, calculator.modulus(14, -4), "14 % -4 should equal 2");
    }

    @Test
    void testModulusByOne() {
        Calculator calculator = new Calculator();
        assertEquals(0, calculator.modulus(25, 1), "25 % 1 should equal 0");
    }

    @Test
    void testModulusByNegativeOne() {
        Calculator calculator = new Calculator();
        assertEquals(0, calculator.modulus(20, -1), "20 % -1 should equal 0");
    }

    @Test
    void testModulusException() {
        Calculator calculator = new Calculator();
        // Division by zero: should throw IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> calculator.modulus(25, 0),
            "Cannot divide by zero should throw IllegalArgumentException");
    }

    @Test
    void testModulusMock() {
        Mockito.when(calculator.modulus(15, 4)).thenReturn(3);
        assertEquals(3, calculator.modulus(15, 4), "15 % 4 should equal 3");
    }

    @Test
    void testModulusMockEdgeCases() {
        Mockito.when(calculator.modulus(0, 6)).thenReturn(0);
        assertEquals(0, calculator.modulus(0, 6), "0 % 6 should equal 0");

        Mockito.when(calculator.modulus(-15, -4)).thenReturn(-3);
        assertEquals(-3, calculator.modulus(-15, -4), "-15 % -4 should equal -3");
    }

    @Test
    void testModulusMockEdgeCase() {
        Calculator calculator = Mockito.mock(Calculator.class);
        Mockito.when(calculator.modulus(75, 30)).thenReturn(15);
        assertEquals(15, calculator.modulus(75, 30), "75 % 30 should equal 15");
    }
}
