
package packagecalculator;

 public class Calculator {
    public int valueStored = 0;
    
    public void resetStoredValue(){
        valueStored = 0;
    }
    
    public boolean isValueStoredZero() {
    	return valueStored == 0;
    }

    public int multiply(int a, int b) {
        return a * b;
    }

    public int divide(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        return a / b;
    }

    public String federalTaxBracket(int income){
        if(income > 235675){
           return "fifth";
        }else if(income >= 165431){
           return "forth";
        }else if(income >= 106718){
           return "third";
        }else if(income >= 53360){
           return "second";
        }else{
           return "first";
        }
    }

    public int modulus(int a, int b){
        if (b == 0){
           throw new IllegalArgumentException("Cannot divide by zero");
        }
        return a - multiply(divide(a,b),b);
    }
}
