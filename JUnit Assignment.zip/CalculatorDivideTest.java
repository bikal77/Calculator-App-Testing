 package packagecalculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class CalculatorDivideTest {

    // Test divide method
    Calculator calculator = new Calculator();

    @Test
    void testDividepositive() {
        // Test for correct division
        assertEquals(4, calculator.divide(8, 2), "8 / 2 should be 4");
    }

    @Test
    void testDividenegative() {
        assertEquals(-8, calculator.divide(-64, 8), "-64 / 8 should be -8");
    }

    @Test
    void testDivideBothnegative() {
        assertEquals(12, calculator.divide(-144, -12), "-144 / -12 should be 12");
    }

    @Test
    void testDivideZeroNumeratorbyNegative() {
        assertEquals(0, calculator.divide(0, -4), "0 / -4 should equal 0");  // Test 0 divided by a negative number
    }

    @Test
    void testDivideZeroNumerator() {
        assertEquals(0, calculator.divide(0, 7), "0 / 7 should equal 0");
    }

    @Test
    void testDivideLargeNumbers() {
        assertEquals(500000, calculator.divide(500000000, 1000), "500000000 / 1000 should equal 500000");
    }

    @Test
    void testDivideByOne() {
        assertEquals(9, calculator.divide(9, 1), "9 / 1 should equal 9");
    }

    @Test
    void testDividePositiveByNegative() {
        assertEquals(-8, calculator.divide(24, -3), "24 / -3 should equal -8");
    }

    @Test
    void testDivideByNegativeOne() {
        assertEquals(-7, calculator.divide(7, -1), "7 / -1 should equal -7");
    }

    @Test
    void testDivideByItself() {
        assertEquals(1, calculator.divide(200, 200), "200 / 200 should equal 1");
    }

    @Test
    void testDividebyZeroException() {
        assertEquals(0, calculator.divide(0, 4));  // Test 0 divided by a non-zero number
        // Test for division by zero
        assertThrows(IllegalArgumentException.class, () -> calculator.divide(9, 0),
                "Cannot divide by zero should throw IllegalArgumentException");
    }
}
