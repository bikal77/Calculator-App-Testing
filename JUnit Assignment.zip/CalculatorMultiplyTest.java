 package packagecalculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorMultiplyTest {

    Calculator calculator;

    @BeforeEach
    void setUp() throws Exception {
        calculator = new Calculator();  // Initialize the Calculator before each test
    }

    @AfterEach
    void tearDown() throws Exception {
        calculator = null;  // Clean up the Calculator object after each test
    }

    // Separate tests for each multiplication scenario

    @Test
    void testMultiplyPositiveNumbers() {
        assertEquals(50, calculator.multiply(5, 10), "5 * 10 should be 50");
    }

    @Test
    void testMultiplyZeroByPositiveNumber() {
        assertEquals(0, calculator.multiply(0, 7), "0 * 7 should be 0");
    }

    @Test
    void testMultiplyNegativeAndPositiveNumber() {
        assertEquals(-18, calculator.multiply(-6, 3), "-6 * 3 should be -18");
    }

    @Test
    void testMultiplyTwoNegativeNumbers() {
        assertEquals(24, calculator.multiply(-4, -6), "-4 * -6 should be 24");
    }

    @Test
    void testMultiplyZeroByZero() {
        assertEquals(0, calculator.multiply(0, 0), "0 * 0 should be 0");
    }

    @Test
    void testMultiplyPositiveNumberByZero() {
        assertEquals(0, calculator.multiply(8, 0), "8 * 0 should be 0");
    }

    @Test
    void testMultiplyLargePositiveNumbers() {
        assertEquals(200000000, calculator.multiply(20000, 10000), "20000 * 10000 should be 200000000");
    }

    @Test
    void testMultiplyLargeNegativeAndPositiveNumbers() {
        assertEquals(-50000000, calculator.multiply(-5000, 10000), "-5000 * 10000 should be -50000000");
    }
}
